package com.example.gzujwcsdkdemo;

import java.util.List;

import com.apexism.jwc.sdk.api.JwcGradePoint;
import com.apexism.jwc.sdk.api.JwcInfo;
import com.apexism.jwc.sdk.api.JwcLogin;
import com.apexism.jwc.sdk.api.JwcScore;
import com.apexism.jwc.sdk.bean.Score;
import com.apexism.jwc.sdk.listener.JwcGradePointListener;
import com.apexism.jwc.sdk.listener.JwcInfoListener;
import com.apexism.jwc.sdk.listener.JwcLoginListener;
import com.apexism.jwc.sdk.listener.JwcScoreListener;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * 主类
 * 
 * @author Zero
 *
 */
public class MainActivity extends Activity {
	
	/**
	 * 各类控件
	 */
	private EditText number;
	private EditText password;
	private Button login;
	private TextView loginState;
	private TextView info;
	private TextView score;
	private TextView point;
	private TextView state;
	
	/**
	 * 教务处对象
	 */
	private JwcLogin jwcLogin = new JwcLogin();
	private JwcInfo jwcInfo = new JwcInfo();
	private JwcScore jwcScore = new JwcScore();
	private JwcGradePoint jwcGradePoint = new JwcGradePoint();

	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initFindViewById();
        
        //设置登陆监听器
        login.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				
				initJwcLogin();
			}
		});
    }  
    /**
     * 初始化各类控件
     */
    private void initFindViewById()
    {
    	number = (EditText) findViewById(R.id.number);
    	password = (EditText) findViewById(R.id.password);
    	loginState = (TextView) findViewById(R.id.loginState);
    	login = (Button) findViewById(R.id.login);
    	info = (TextView) findViewById(R.id.info);
    	score = (TextView) findViewById(R.id.score);
    	point = (TextView) findViewById(R.id.point);
    	state = (TextView) findViewById(R.id.state);
    }
    
    
    /**
     * 登陆教务处
     *
     * 这个必须先进行初始化,只有登陆了才有可能获取成绩、个人信息、绩点等。
     */
    private void initJwcLogin()
    {
    	
    	//请求服务器，监听状态
    	jwcLogin.request(number.getText().toString(), password.getText().toString(), new JwcLoginListener() {
			
    		@Override
			public void loginStart() {
				// TODO 自动生成的方法存根
				
				state.setText("开始登陆中...");
				
			}
			
			@Override
			public void loginFail() {
				// TODO 自动生成的方法存根
		
				state.setText("登陆失败");
				
				loginState.setText("登陆失败\n");
				
			}

			@Override
			public void loginSuccess() {
				// TODO 自动生成的方法存根
				
	
				state.setText("登陆成功");
				
			    loginState.setText("登陆成功\n");
				
				initJwcInfo();	
				
			}
		});
    	
    	
    	
    }
    
    /**
     * 初始化学生信息
     * 
     * 必需在登陆教务处之后才可以调用
     */
    private void initJwcInfo()
    {
    	
    	jwcInfo.request(new JwcInfoListener() {
			
    		@Override
			public void infoSuccess(String number, String name, String sex,
					String academy, String especial) {
				// TODO 自动生成的方法存根
				
				  state.setText("获取个人信息成功");
				
				  info.setText("学号：" + number + "\n" + 
				    		"姓名：" + name + "\n" + 
				    		"性别：" + sex +  "\n" + 
				    		"学院：" + academy + "\n" + 
				    		"专业：" + especial + "\n");
					
				  initJwcScore();
				
			}
			
			@Override
			public void infoStart() {
				// TODO 自动生成的方法存根
				
				  state.setText("开始获取学生信息中...");
				
			}
			
			@Override
			public void infoFail() {
				// TODO 自动生成的方法存根
				
				  state.setText("获取学生信息失败");
				
			}
		});
  
    	
    }
    
    /**
     * 初始化教务处个人学生成绩
     * 
     * 必需在登陆教务处之后才可以调用
     */
    private void initJwcScore()
    {
    	//请求教务处学生成绩，这里是获取2014-2015学年第一学期成绩   	
    	jwcScore.request("2014-2015", "1", new JwcScoreListener() {
			
    		@Override
			public void scoreSuccess(List<Score> scores) {
				// TODO 自动生成的方法存根
				
				String str = "";
				
				for(Score score : scores)
				{
					str += score.getName() + "：" + score.getScore() + "\n";
				}
				
				MainActivity.this.score.setText(str);
				
				state.setText("获取成绩成功");
				
				initJwcGradePoint();
			}
			
			@Override
			public void scoreStart() {
				// TODO 自动生成的方法存根
				
				state.setText("开始获取成绩中...");
			}
			
			@Override
			public void scoreFail() {
				// TODO 自动生成的方法存根
				
				state.setText("获取成绩失败");
				
			}
		});
    	
    }
    
    /**
     * 初始化教务处学生绩点
     * 
     * 必需在登陆教务处之后才可以调用
     */
    private void initJwcGradePoint()
    {
    	//请求教务处学生绩点，这里是获取2014-2015学年第一学期绩点   	
    	jwcGradePoint.request("2014-2015", "1", new JwcGradePointListener() {
			
    		@Override
			public void gradePointSuccess(String gradePoint) {
				// TODO 自动生成的方法存根
				
				state.setText("获取绩点成功");
				
				point.setText("绩点：" + gradePoint + "\n" );
				
			}
			
			@Override
			public void gradePointStart() {
				// TODO 自动生成的方法存根
				
				state.setText("开始获取绩点中...");
			}
			
			@Override
			public void gradePointFail() {
				// TODO 自动生成的方法存根
				
				state.setText("获取绩点失败");				
			}
		});  
    }    
}
